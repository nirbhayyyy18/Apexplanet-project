<?php
session_start();
include 'includes/db_connection.php';

// Redirect if not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: auth/login.php");
    exit();
}

$username = $_SESSION['username'];

// Logout logic
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: index.php");
    exit();
}

// Pagination variables
$posts_per_page = 5;
$page = isset($_GET['page']) && is_numeric($_GET['page']) ? $_GET['page'] : 1;
$offset = ($page - 1) * $posts_per_page;

// Search logic
$search = isset($_GET['search']) ? trim($_GET['search']) : '';

// SQL query for posts with search and pagination
if ($search) {
    $stmt = $conn->prepare("SELECT * FROM posts WHERE title LIKE :search OR content LIKE :search ORDER BY created_at DESC LIMIT :offset, :limit");
    $stmt->bindValue(':search', "%$search%", PDO::PARAM_STR);
} else {
    $stmt = $conn->prepare("SELECT * FROM posts ORDER BY created_at DESC LIMIT :offset, :limit");
}
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->bindValue(':limit', $posts_per_page, PDO::PARAM_INT);
$stmt->execute();
$posts = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Total post count for pagination
$total_stmt = $conn->prepare($search
    ? "SELECT COUNT(*) FROM posts WHERE title LIKE :search OR content LIKE :search"
    : "SELECT COUNT(*) FROM posts");
if ($search) {
    $total_stmt->bindValue(':search', "%$search%", PDO::PARAM_STR);
}
$total_stmt->execute();
$total_posts = $total_stmt->fetchColumn();
$total_pages = ceil($total_posts / $posts_per_page);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f0f2f5;
        }
        nav {
            background-color: #343a40;
            color: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 20px;
        }
        nav span {
            font-size: 18px;
        }
        nav a {
            color: white;
            text-decoration: none;
            padding: 10px 15px;
            background-color: #007BFF;
            border-radius: 5px;
            transition: background 0.3s;
        }
        nav a:hover {
            background-color: #0056b3;
        }
        .container {
            max-width: 1200px;
            margin: 20px auto;
            padding: 20px;
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        h1{
            background-color: #ccc;
        }
        h2 {
            color: #333;
            margin-bottom: 10px;
        }
        .section {
            margin-bottom: 30px;
        }
        form input, form textarea, form button {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        form button {
            background-color: #28a745;
            color: white;
            font-weight: bold;
            cursor: pointer;
            transition: background 0.3s;
        }
        form button:hover {
            background-color: #218838;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 15px;
            border: 1px solid #ddd;
            text-align: left;
        }
        th {
            background-color: #343a40;
            color: white;
        }
        td a {
            text-decoration: none;
            padding: 5px 10px;
            margin-right: 5px;
            border-radius: 5px;
            font-size: 14px;
        }
        td a.edit {
            background-color: #007BFF;
            color: white;
        }
        td a.edit:hover {
            background-color: #0056b3;
        }
        td a.delete {
            background-color: #dc3545;
            color: white;
        }
        td a.delete:hover {
            background-color: #c82333;
        }
        .no-posts {
            text-align: center;
            color: #777;
            font-size: 16px;
        }
        .pagination {
            text-align: center;
            margin-top: 20px;
        }
        .pagination a {
            margin: 0 5px;
            padding: 8px 15px;
            text-decoration: none;
            background-color: #007BFF;
            color: white;
            border-radius: 5px;
        }
        .pagination a:hover {
            background-color: #0056b3;
        }
        .pagination .active {
            background-color: #0056b3;
        }
        /* Sidebar styling */
        .sidebar {
            height: 100%;
            width: 0;
            position: fixed;
            top: 0;
            right: 0;
            background-color: #111;
            overflow-x: hidden;
            transition: 0.5s;
            padding-top: 60px;
            display: flex;
            flex-direction: column;
            z-index: 100;
        }

        .sidebar ul {
            list-style-type: none;
            padding: 0;
        }

        .sidebar li {
            text-align: center;
        }

        .sidebar a {
            padding: 15px;
            text-decoration: none;
            font-size: 18px;
            color: white;
            display: block;
            transition: 0.3s;
        }

        .sidebar a:hover {
            background-color: #ddd;
            color: black;
        }

        /* Hamburger Icon Styling (Right Side) */
        .menu {
            position: absolute;
            top: 20px;
            right: 20px; /* Move hamburger menu to the right */
            cursor: pointer;
            z-index: 101;
        }

        .line {
            width: 35px;
            height: 5px;
            background-color: #333;
            margin: 6px 0;
            transition: 0.4s;
        }

        /* Main content styling */
        #main-content {
            padding: 20px;
            margin-left: 0;
        }

        /* Sidebar Open Animation */
        .sidebar.open {
            width: 250px;
        }

        /* Hamburger Menu Open Animation */
        .menu.open .line:nth-child(1) {
            transform: rotate(-45deg) translate(-5px, 6px);
        }

        .menu.open .line:nth-child(2) {
            opacity: 0;
        }

        .menu.open .line:nth-child(3) {
            transform: rotate(45deg) translate(-5px, -6px);
        }
    </style>
</head>
<body>
    <nav>
        <span>Welcome, <?= htmlspecialchars($username); ?></span>
         <!-- Navbar Section -->
    <!-- Hamburger Menu Icon -->
    <div class="menu" onclick="toggleSidebar()">
        <div class="line"></div>
        <div class="line"></div>
        <div class="line"></div>
    </div>

    <!-- Sidebar -->
    <div id="sidebar" class="sidebar">
    
        <ul>
            <li><a href="edit_profile.php">Edit Profile</a></li>
            <li><a href="user_details.php">User Details</a></li>
            <li><a href="auth/logout.php">Logout</a></li>
        </ul>
    </nav>

    <div class="container">
        <h1>Dashboard</h1>

        <!-- Create Post -->
        <div class="section">
            <h2>Create Post</h2>
            <form method="POST" action="create.php">
                <input type="text" name="title" placeholder="Post Title" required>
                <textarea name="content" placeholder="Post Content" rows="4" required></textarea>
                <button type="submit"><i class="fas fa-plus-circle"></i> Create Post</button>
            </form>
        </div>

        <!-- Search -->
        <div class="section">
            <h2>Search</h2>
            <form method="GET" action="">
                <input type="text" name="search" placeholder="Search posts..." value="<?= htmlspecialchars($search); ?>">
                <button type="submit"><i class="fas fa-search"></i> Search</button>
            </form>
        </div>

        <!-- Posts -->
        <div class="section">
            <h2>All Posts</h2>
            <?php if (empty($posts)): ?>
                <p class="no-posts">No posts found. <?= $search ? "Try a different search query." : "Create one now!" ?></p>
            <?php else: ?>
            <table>
                <thead>
                    <tr>
                        <th>Title</th>
                        <th>Content</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($posts as $post): ?>
                    <tr>
                        <td><?= htmlspecialchars($post['title']); ?></td>
                        <td><?= htmlspecialchars($post['content']); ?></td>
                        <td>
                            <a href="update.php?id=<?= $post['id']; ?>" class="edit"><i class="fas fa-edit"></i> Edit</a>
                            <a href="delete.php?id=<?= $post['id']; ?>" class="delete"><i class="fas fa-trash"></i> Delete</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php endif; ?>

        <script>
            // script.js
            function toggleSidebar() {
                const sidebar = document.getElementById("sidebar");
                const menu = document.querySelector(".menu");
                
                // Toggle the sidebar visibility
                sidebar.classList.toggle("open");
                
                // Toggle the hamburger icon animation
                menu.classList.toggle("open");
            }
        </script>

                <!-- Pagination -->
                <div class="pagination">
                <?php if ($total_pages > 1): ?>
                    <?php 
                        // Previous Page
                        if ($page > 1): ?>
                            <a href="?search=<?= urlencode($search); ?>&page=<?= $page - 1; ?>">Previous</a>
                    <?php endif; ?>

                    <!-- Page Number Links -->
                    <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                        <a href="?search=<?= urlencode($search); ?>&page=<?= $i; ?>" class="<?= $i == $page ? 'active' : ''; ?>">
                            <?= $i; ?>
                        </a>
                    <?php endfor; ?>

                    <!-- Next Page -->
                    <?php if ($page < $total_pages): ?>
                        <a href="?search=<?= urlencode($search); ?>&page=<?= $page + 1; ?>">Next</a>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html>