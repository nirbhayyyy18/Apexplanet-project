<?
function checkRole($role) {
    if (!isset($_SESSION['role']) || $_SESSION['role'] !== $role) {
        echo "Access Denied. You do not have permission to view this page.";
        exit;
    }
}
?>
