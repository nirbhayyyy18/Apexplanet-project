**Table Name**: posts

| Column Name | Data Type      | Constraints                 | Description                    |
|-------------|----------------|-----------------------------|--------------------------------|
| id          | INT            | Primary Key, Auto Increment | Unique ID for each post       |
| title       | VARCHAR(255)   | NOT NULL                   | Title of the blog post        |
| content     | TEXT           | NOT NULL                   | Content of the blog post      |
| created_at  | TIMESTAMP      | DEFAULT CURRENT_TIMESTAMP   | Timestamp when post was created |




**Table Name**: users

| Column Name | Data Type      | Constraints                 | Description                    |
|-------------|----------------|-----------------------------|--------------------------------|
| id          | INT            | Primary Key, Auto Increment | Unique ID for each user       |
| username    | VARCHAR(50)    | NOT NULL, UNIQUE            | Username of the user          |
| password    | VARCHAR(255)   | NOT NULL                   | Hashed password for security  |
