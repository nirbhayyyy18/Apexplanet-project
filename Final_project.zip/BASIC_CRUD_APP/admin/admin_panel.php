<?php
session_start();
include '../includes/db_connection.php';
include '../middleware.php';

// Restrict access to admins only
middleware('admin');

// Fetch all users from the database
$stmt = $conn->prepare("SELECT id, username, email, role FROM users");
$stmt->execute();
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = htmlspecialchars($_POST['user_id']);
    $new_role = htmlspecialchars($_POST['role']);

    // Update the role of the selected user
    $update_stmt = $conn->prepare("UPDATE users SET role = :role WHERE id = :id");
    $update_stmt->execute([':role' => $new_role, ':id' => $user_id]);
    header("Location: admin_panel.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <h1>Admin Panel</h1>
    <h2>Manage Users</h2>

    <table border="1">
        <thead>
            <tr>
                <th>Username</th>
                <th>Email</th>
                <th>Role</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($users as $user): ?>
                <tr>
                    <td><?= htmlspecialchars($user['username']); ?></td>
                    <td><?= htmlspecialchars($user['email']); ?></td>
                    <td><?= htmlspecialchars($user['role']); ?></td>
                    <td>
                        <form method="POST" action="admin_panel.php">
                            <input type="hidden" name="user_id" value="<?= $user['id']; ?>">
                            <select name="role">
                                <option value="user" <?= $user['role'] === 'user' ? 'selected' : ''; ?>>User</option>
                                <option value="editor" <?= $user['role'] === 'editor' ? 'selected' : ''; ?>>Editor</option>
                                <option value="admin" <?= $user['role'] === 'admin' ? 'selected' : ''; ?>>Admin</option>
                            </select>
                            <button type="submit">Update Role</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>
</html>
