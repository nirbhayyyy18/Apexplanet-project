<?php
session_start();  // Start the session

// Include database connection
include('./includes/db_connection.php');

// Check if the user is logged in, if not redirect to login page
if (!isset($_SESSION['username'])) {
    header("Location: index.php");  // Redirect to login page (index.php)
    exit;
}

// Get the current user info from the database
$username = $_SESSION['username'];
$stmt = $conn->prepare("SELECT * FROM users WHERE username = :username");
$stmt->bindParam(':username', $username, PDO::PARAM_STR);
$stmt->execute();
$user = $stmt->fetch(PDO::FETCH_ASSOC);

// If the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the new values from the form
    $new_username = htmlspecialchars($_POST['username']);
    $new_email = htmlspecialchars($_POST['email']);
    $new_password = htmlspecialchars($_POST['password']);

    // Validate and update the data
    if (!empty($new_username) && !empty($new_email)) {
        // If password is provided, hash it
        if (!empty($new_password)) {
            $new_password = password_hash($new_password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("UPDATE users SET username = :username, email = :email, password = :password WHERE username = :old_username");
            $stmt->bindParam(':password', $new_password);
        } else {
            $stmt = $conn->prepare("UPDATE users SET username = :username, email = :email WHERE username = :old_username");
        }
        
        // Bind the new values
        $stmt->bindParam(':username', $new_username);
        $stmt->bindParam(':email', $new_email);
        $stmt->bindParam(':old_username', $username);

        // Execute the update query
        if ($stmt->execute()) {
            $_SESSION['username'] = $new_username; // Update session username
            header("Location: dashboard.php"); // Redirect to dashboard after update
            exit;
        } else {
            $error = "Failed to update profile.";
        }
    } else {
        $error = "All fields are required.";
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profile</title>
</head>
<body>
    <h2>Edit Profile</h2>

    <?php if (isset($error)): ?>
        <p style="color: red;"><?= $error ?></p>
    <?php endif; ?>

    <form action="edit_profile.php" method="POST">
        <label for="username">Username:</label>
        <input type="text" name="username" id="username" value="<?= htmlspecialchars($user['username']) ?>" required><br><br>

        <label for="email">Email:</label>
        <input type="email" name="email" id="email" value="<?= htmlspecialchars($user['email']) ?>" required><br><br>

        <label for="password">New Password (leave empty if you don't want to change it):</label>
        <input type="password" name="password" id="password"><br><br>

        <button type="submit">Update Profile</button>
    </form>

    <p><a href="dashboard.php">Back to Dashboard</a></p>
</body>
</html>
