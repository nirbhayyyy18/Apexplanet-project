<?php
session_start();  // Start the session

// Include database connection
include('./includes/db_connection.php');

// Check if the user is logged in, if not redirect to login page
if (!isset($_SESSION['username'])) {
    header("Location: index.php");  // Redirect to login page (index.php)
    exit;
}

// Get the current user info from the database
$username = $_SESSION['username'];
$stmt = $conn->prepare("SELECT * FROM users WHERE username = :username");
$stmt->bindParam(':username', $username, PDO::PARAM_STR);
$stmt->execute();
$user = $stmt->fetch(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Details</title>
</head>
<body>
    <h2>User Details</h2>
    
    <p><strong>Username:</strong> <?= htmlspecialchars($user['username']) ?></p>
    <p><strong>Email:</strong> <?= htmlspecialchars($user['email']) ?></p>

    <p><a href="edit_profile.php">Edit Profile</a></p>
    <p><a href="dashboard.php">Back to Dashboard</a></p>
</body>
</html>
