<?php
// Enter the password you want to hash
$password = 'password'; // Replace this with the actual password you want to hash

// Generate the hash using the password_hash() function
$hashed_password = password_hash($password, PASSWORD_DEFAULT);

// Print the hashed password
echo $hashed_password;
?>
