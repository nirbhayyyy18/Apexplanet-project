<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: auth/login.php");
    exit();
}

include 'includes/db_connection.php';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = trim($_POST['title']);
    $content = trim($_POST['content']);

    // Server-side validation
    $errors = [];

    // Validate title
    if (empty($title)) {
        $errors[] = "Title is required.";
    } elseif (strlen($title) > 255) {
        $errors[] = "Title cannot exceed 255 characters.";
    }

    // Validate content
    if (empty($content)) {
        $errors[] = "Content is required.";
    } elseif (strlen($content) < 10) {
        $errors[] = "Content must be at least 10 characters long.";
    }

    // If no errors, proceed with database insertion
    if (empty($errors)) {
        $stmt = $conn->prepare("INSERT INTO posts (title, content, created_at) VALUES (:title, :content, NOW())");
        $stmt->bindValue(':title', $title, PDO::PARAM_STR);
        $stmt->bindValue(':content', $content, PDO::PARAM_STR);
        $stmt->execute();
        header("Location: dashboard.php"); // Redirect after successful insertion
        exit();
    }
}
?>

<h1>Create a New Post</h1>
<?php if (!empty($errors)): ?>
    <div class="errors">
        <?php foreach ($errors as $error): ?>
            <p style="color: red;"><?= htmlspecialchars($error); ?></p>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<form method="POST" action="create.php">
    <input type="text" name="title" placeholder="Post Title" required maxlength="255">
    <textarea name="content" placeholder="Post Content" rows="4" required minlength="10"></textarea>
    <button type="submit">Create Post</button>
</form>

<script>
    // Client-side validation
    document.querySelector("form").addEventListener("submit", function(e) {
        let title = document.querySelector("[name='title']").value;
        let content = document.querySelector("[name='content']").value;
        let errors = [];

        // Title validation
        if (!title) {
            errors.push("Title is required.");
        } else if (title.length > 255) {
            errors.push("Title cannot exceed 255 characters.");
        }

        // Content validation
        if (!content) {
            errors.push("Content is required.");
        } else if (content.length < 10) {
            errors.push("Content must be at least 10 characters long.");
        }

        // Show errors if any
        if (errors.length > 0) {
            e.preventDefault(); // Prevent form submission
            alert(errors.join("\n"));
        }
    });
</script>


