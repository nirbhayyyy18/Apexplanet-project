<?php
function middleware($required_role) {
    session_start();
    if (!isset($_SESSION['role']) || $_SESSION['role'] !== $required_role) {
        // Redirect to no_access page if role doesn't match
        header("Location: ../no_access.php");
        exit();
    }
}
