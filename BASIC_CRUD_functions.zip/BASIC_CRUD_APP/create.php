<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: auth/login.php");
    exit();
}
?>

<?php
include 'include/db_connection.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title'];
    $content = $_POST['content'];

    $sql = "INSERT INTO posts (title, content) VALUES (:title, :content)";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['title' => $title, 'content' => $content]);

    header("Location: index.php");
    exit();
}
?>

<h1>Create a New Post</h1>
<form method="POST" action="">
    <input type="text" name="title" placeholder="Enter title" required>
    <textarea name="content" placeholder="Enter content" required></textarea>
    <button type="submit">Create Post</button>
</form>
