

<?php
session_start();
include 'include/db_connection.php';

// Check if the user is logged in
if (isset($_SESSION['user_id'])) {
    echo "<p>Welcome, " . htmlspecialchars($_SESSION['username']) . "!</p>";
    echo "<a href='auth/logout.php'>Logout</a>";
} else {
    echo "<a href='auth/login.php'>Login</a>";
    echo " | ";
    echo "<a href='auth/register.php'>Register</a>";
}

$sql = "SELECT * FROM posts ORDER BY created_at DESC";
$stmt = $conn->query($sql);
$posts = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>








