<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: auth/login.php");
    exit();
}
?>

<?php
include 'include/db_connection.php';

$sql = "SELECT * FROM posts ORDER BY created_at DESC";
$stmt = $conn->query($sql);
$posts = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<h1>All Posts</h1>
<a href="create.php">Create New Post</a>
<ul>
    <?php foreach ($posts as $post): ?>
        <li>
            <h2><?= htmlspecialchars($post['title']) ?></h2>
            <p><?= htmlspecialchars($post['content']) ?></p>
            <a href="update.php?id=<?= $post['id'] ?>">Edit</a>
            <a href="delete.php?id=<?= $post['id'] ?>">Delete</a>
        </li>
    <?php endforeach; ?>
</ul>
